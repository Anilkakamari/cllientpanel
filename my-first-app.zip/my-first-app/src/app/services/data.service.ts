import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {of} from 'rxjs';

import {User} from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  users: User[] = [];
  data: Observable<any>;

  constructor() {
    this.users = [
      {
        firstName: 'Anil',
        lastName: 'Kakamari',
        email: 'anil.k@gmail.com',
        isActive: true,
        currentDate: new Date('03/02/2018 06:20:00'),
        hide: true
      },
      {
        firstName: 'Sachin',
        lastName: 'Khot',
        email: 'anil.k@gmail.com',
        isActive: true,
        currentDate: new Date('03/02/2018 06:20:00'),
        hide: true
      },
      {
        firstName: 'Santosh',
        lastName: 'Parashetti',
        email: 'anil.k@gmail.com',
        isActive: true,
        currentDate: new Date('03/02/2018 06:20:00'),
        hide: true
      }
    ];
  }

  getData(){
    this.data = new Observable(observer => {
      setTimeout(() => {
        observer.next(1);
      }, 1000);

      setTimeout(() => {
        observer.next(2);
      }, 2000);

      setTimeout(() => {
        observer.next(3);
      }, 3000);

      setTimeout(() => {
        observer.next({name: 'anil'});
      }, 4000);
    });
    return this.data;
  }

  getUsers():Observable<User[]>{
    return of(this.users);
  }

  addUser(user:User){
    this.users.unshift(user);
  }
}
