import { Component, OnInit } from '@angular/core';

import {User} from '../models/User';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  //Properties
  user:User;

  //Using Types
  // firstName : string;
  // lastName : string;
  // age : number;
  // address;

  // foo: any;
  // hasKids: boolean;
  // numberArray : number[];
  // stringArray : string[];
  // mixedArray: any[];
  // myTouple : [string,number,boolean];
  // unusable: void;
  // u: undefined;
  // n: null;
  //Methods
  constructor() { 
    this.user = {
    firstName : 'Anil',
    lastName : 'Kakamari',
      email: 'anil@gmail.com'
  }

    // this.foo = true;
    // this.hasKids = true;
    // this.numberArray = [1,2,3];
    // this.stringArray = ['Hello', 'World'];
    // this.mixedArray = [1,true,'hello'];
    // this.myTouple = ['Hello',29,true];
    // this.unusable = undefined;
    // this.n = null;
    console.log(this.addNumber(1,6));
  }
 

  addNumber(num1: number,num2: number):number{
    return num1 + num2;
  }
  
  ngOnInit() {
  }

}
