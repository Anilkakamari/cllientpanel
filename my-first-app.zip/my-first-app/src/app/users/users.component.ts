import { Component, OnInit } from '@angular/core';
import {User} from '../models/User';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  user: User = {
    firstName: '',
    lastName: '',
    email: ''
  }
  users:User[]=[];
  showExtended: boolean = true;
  loaded: boolean = false;
  loaded1: boolean = false;
  enableAdd: boolean = false;
  enableStyle: boolean = false;
  showUserForm: boolean = false;
  currentClasses = {};
  currentStyles = {};
  // @ViewChild('userForm') form : any;
  form: any;

  constructor(private dataservice: DataService) { }

  ngOnInit() {
    setTimeout(() => {
      
      this.dataservice.getUsers().subscribe(users => {
      this.users = users;
      this.loaded = true;
      });
      
    }, 2000);

    this.dataservice.getData()
    .subscribe(data => {
      console.log(data);
    });

    this.setCurrentClasses();
    this.setCurrentStyles();
  }

  setCurrentClasses(){
    this.currentClasses = {
      'btn-success' : this.enableAdd,
      'big-text' : this.showExtended
    }
  }

  setCurrentStyles(){
    this.currentStyles = {
      'font-size' : this.enableStyle ? '0' : '20px',
      'display' : 'flex',
      'align-items' : 'center',
      'justify-content' : 'space-between',
      'margin' : '0'
    }
  }
 
  // onSubmit(e){
  //   console.log(123);
  //   e.preventDefault();
  // }

  addUser(){
    this.user.currentDate = new Date();
    this.users.unshift(this.user);
  }

  onSubmit({value, valid}:{value:User, valid:boolean}){
    if(!valid){
      console.log('Forms is not valid');
    }else{
      value.hide = true;
      value.isActive = true;
      value.currentDate = new Date();

      this.dataservice.addUser(value);
      this.form.reset();
    }
  }
}
