import { Component, OnInit, ViewChild } from '@angular/core';
import { Client } from '../models/Client'


@Component({
  selector: 'app-addclient',
  templateUrl: './addclient.component.html',
  styleUrls: ['./addclient.component.scss']
}) 
export class AddclientComponent implements OnInit {
  @ViewChild('clientForm') form: any;

  client: Client = {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    balance: 0
  }

  disableBalanceOnAdd: boolean = false;
  onSubmit({value, valid} : {value: Client, valid: boolean}){
    console.log(value, valid);
  }

  constructor() { }

  ngOnInit() {
  }

}
