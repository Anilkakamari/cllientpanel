export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAZ9PPmESqzySyLEFkOAtEt1xHMcFFvAds",
    authDomain: "clientpanel-92644.firebaseapp.com",
    databaseURL: "https://clientpanel-92644.firebaseio.com",
    projectId: "clientpanel-92644",
    storageBucket: "clientpanel-92644.appspot.com",
    messagingSenderId: "396774577699",
    appId: "1:396774577699:web:9f5baa71ea65965c110396",
    measurementId: "G-LRJ8M45HZC"
  }
};
