import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {Observable} from 'rxjs';

import {Log} from '../models/Log';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  logs: Log[];

  private logSourse = new BehaviorSubject<Log>({id: null, text: null, date: null});
  selectedLog = this.logSourse.asObservable();

  constructor() {
    this.logs = [
      {id: '1', text: 'Generate Component', date: new Date()},
      {id: '2', text: 'Add Login', date: new Date()}
    ]
  }

  getLogs(){
    return this.logs;
  }

  setFormLog(log:Log){
    this.logSourse.next(log);
  }
}
