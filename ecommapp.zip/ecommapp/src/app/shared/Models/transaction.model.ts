export interface Transaction {
  date: any;
  time: any;
  balance: number;
  updatedbalance: number;
  operation: string;
}
