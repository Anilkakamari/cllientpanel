export interface Tutorial {
  name: string;
  url: string;
}
