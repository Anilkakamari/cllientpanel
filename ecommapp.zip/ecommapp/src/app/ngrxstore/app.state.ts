import { Tutorial } from "./tutorial.model";

export interface AppState {
  readonly tutorial: Tutorial[];
}
